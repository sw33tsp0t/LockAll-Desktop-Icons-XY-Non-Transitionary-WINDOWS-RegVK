double click registry file
to add to local disk registry

~Complete~ !!!!

========================================================================================
enables lock of all desktop icons posistion, without transition from alterior sources,
such as,
Resolution, App Adjustment, or Memory

Perfect for an Organized Desktop Worth Keeping in Perfect Placement Value.
without Alterior Transitions
========================================================================================


Compatable with: ALL WINDOWS VERSIONS

- Win 98
- Win 2000/ME
- Win XP
- Win Vista
- Win 7
========================================================================================
- Win 8/8.1/8.2
- Win 10
========================================================================================


Source Compile By:
	Matthew Cartwright (c) Double-M-Labs 2020
